from chatBot import ChatBot #importa classe ChatBot() do arquivo chatBot.py

bot = ChatBot("Lili") #cria variável "bot" chamada "Lili"_
    #_cada nome passado pelo argumento será um bot diferente com memórias diferentes.

print ('Conectando com '+bot.nome+'...') #diz com qual bot você esta falando
print ('Conectado, diga "Oi"!')
print ('Você pode digitar "Aprende", para ensinar algo ao(a)'+bot.nome+'!')
while True: #repetição infinita
    frase = bot.escuta() #def escuta
    resp = bot.pensa(frase) #def pensa
    bot.fala(resp) #def fala
    if resp == 'tchau': #critério para término quando o usuário digitar "Tchau"
        break
    
