def respostaCaixaBaixa():
    #essa função captura a variável referênciada do usuário e armazena em caixa baixa.
    lowr = input('>: ')
    lowr = lowr.lower()
    lowr = lowr.replace ('é','e')
    return lowr

def pegaNome(nome):
    #caso o usuário digite uma frase, essa linha captura apenas o nome.
    if 'meu nome e ' in nome:
        nome = nome [11:]

    #coloca a primeira letra de cada palavra em maiúsculo.
    nome = nome.title()
    return nome

def reconheceNome(nome):
    #array armazenando nomes conhecidos.
    conhecidos = ['Brenda','Leonardo']

    #se haver algum nome conhecido na array, ela trata de forma diferente.
    if nome in conhecidos:
        frase = 'Eae '
    else:
        frase = 'Muito prazer '
    return frase+nome

#início aqui!

#a bot se apresenta e armazena o nome do usuário.
print('Olá, meu nome é Lili, qual é o seu?')
nome = pegaNome(respostaCaixaBaixa())
respResult = reconheceNome(nome)
print (respResult)

#bot puxando assunto, critério de saída quando o usuário digitar 'tchau'.
print ('Você está bem?')
while True:
    resp = respostaCaixaBaixa()
    if resp == 'tchau':
        break
    else:
        print('Se despeça!')#aqui provavelmente terá uma função com toda uma conversa com a bot.
print ('Tchau!')
exit()
