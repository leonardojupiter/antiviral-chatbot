print('Olá, meu nome é Lili, qual é o seu?')
nome = input('>: ')

if 'Meu nome é ' in nome:
    nome = nome [11:]

if nome == 'Leonardo':
    print('Onii-chan!')
else:
    print('Muito prazer '+nome+'!')
    
