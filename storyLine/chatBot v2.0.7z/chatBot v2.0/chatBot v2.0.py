from funcoesBot import *
#importa todas as funções do arquivo, necessário estar no mesmo diretório.

#a bot se apresenta e armazena o nome do usuário.
print('Olá, meu nome é Lili, qual é o seu?')
nome = pegaNome(respostaCaixaBaixa())
respResult = reconheceNome(nome)
print (respResult)

#bot puxando assunto, critério de saída quando o usuário digitar 'tchau'.
print ('Você está bem?')
while True:
    resp = respostaCaixaBaixa()
    if resp == 'tchau':
        break
    else:
        print('Se despeça!')
print ('Tchau!')
exit()
