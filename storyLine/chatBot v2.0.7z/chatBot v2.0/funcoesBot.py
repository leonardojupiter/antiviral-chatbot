#funções separadas por boas práticas de programação.

def respostaCaixaBaixa():
    #captura a variável referênciada e armazena em caixa baixa.
    lowr = input('>: ')
    lowr = lowr.lower()
    lowr = lowr.replace ('é','e')
    return lowr

def pegaNome(nome):
    #caso o usuário digite uma frase, essa linha captura apenas o nome.
    if 'meu nome e ' in nome:
        nome = nome [11:]

    #a primeira letra de cada palavra em maiúsculo.
    nome = nome.title()
    return nome

def reconheceNome(nome):
    #array armazenando nomes conhecidos.
    conhecidos = ['Brenda','Leonardo']

    #nomes conhecidos na array, ela trata de forma diferente.
    if nome in conhecidos:
        frase = 'Eae '
    else:
        frase = 'Muito prazer '
    return frase+nome
