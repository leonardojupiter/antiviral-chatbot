from chatBot import ChatBot
from selenium import webdriver
import time

bot = ChatBot("Auzio")

class WhatsBot:
    def __init__(self):
        self.mensagem = 'Bom dia!'
        self.grupos = ["8th Semestre"]
        options = webdriver.ChromeOptions()
        options.add_argument('lang=pt-br')
        self.driver = webdriver.Chrome(executable_path=r'./chromedriver.exe')

    def enviarMsgEmGrupos(self):
        #<span dir="auto" title="8th Semestre" class="_3ko75 _5h6Y_ _3Whw5">8th Semestre</span>
        #<div tabindex="-1" class="_3uMse"></div>
        #<span data-testid="send" data-icon="send" class=""></span>
        self.abreChrome()
        for grupo in self.grupos:
            grupo = self.driver.find_element_by_xpath(f"//span[@title='{grupo}']")
            time.sleep(3)
            grupo.click()
            chat_box = self.driver.find_element_by_class_name('_3uMse')
            time.sleep(3)
            chat_box.click()
            chat_box.send_keys(self.mensagem)
            botão_enviar = self.driver.find_element_by_xpath("//span[@data-icon='send']")
            time.sleep(3)
            botão_enviar.click()
            time.sleep(5)

    def abreChrome(self):
        self.driver.get('https://web.whatsapp.com/')
        time.sleep(15)

whats = WhatsBot()
whats.abreChrome()
print ('Conectando com '+bot.nome+'...')
print ('Conectado, diga "Oi"!')
print ('Você pode digitar "Aprende", para ensinar algo ao(a) '+bot.nome+'!')
while True:
    frase = bot.escuta()
    resp = bot.pensa(frase)
    bot.fala(resp)
    if resp == 'tchau':
        break

#whats.enviarMsgEmGrupos()

#<span aria-label="+55 11 95555-5555:"></span>
#<span aria-label="You:"></span>
    
