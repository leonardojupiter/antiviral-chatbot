import json #usada para salvar a memória do bot
import sys #usada para o bot descobrir se o usuário está em Windows, Mac ou Linux
import os #usada para o bot conseguir abrir programas no Windows
import subprocess #usada para o bot conseguir abrir programas no Linux

class ChatBot(): #classe principal
        def __init__(self, nome): #método "__init__" é o primeiro método executado de uma classe, nele_
        #_usando o "self" é possivel atribuir um bot diferente a cada novo nome de bot, como se fosse um "ID".
                try:
                        memoria = open(nome+'.json','r') #se ele encontrar um arquivo json com o mesmo nome dele, ele |r|ead
                except FileNotFoundError:
                        memoria = open(nome+'.json','w') #se ele não encontrar, ele cria e |w|rite
                        memoria.write('["Alan Turing","Katie Bouman"]') #nomes default de conhecimento do bot
                        memoria.close() #fecha o arquivo criado
                        memoria = open(nome+'.json','r') #agora que ele já foi criado, ele |r|ead
                self.nome = nome #nome do bot passado pelo argumento associado ao self
                self.conhecidos = json.load(memoria) #carrega o json
                memoria.close() #fecha o json
                self.historico = [] #histórico do bot, atualmente em uma array temporária_
                        #_futuramente em um json para sabermos o que ele aprendeu
                botFrases = open('BotFrases.json','r')
                self.frases = json.load(botFrases)

        def recoloca(self, frase):
                frase = frase.lower()
                frase = frase.replace ('vc','você')
                return frase
                
        def escuta(self, frase=None): #o bot self.nome "escuta" o que o usuário vai digitar, deixa em caixa baixa_
                        #_e troca caracteres especiais para o ASC "simples"
                if frase == None:
                        frase = input('>: ')
                frase = str(frase)
                frase = frase.lower()
                self.recoloca(frase)
                return frase
        
        def pensa(self, frase): #o bot self.nome "pensa" na frase que retornou do método anterior
                try:
                        if frase in self.frases: #se a frase for uma frase que o bot já conhece_
                                        #_ele da a resposta que esta associada aquela frase na memória dele
                                return self.frases[frase] #retorna resposta associada a frase_
                                #_(se ele já viu aquela frase antes e recebeu uma resposta)
                        if frase == 'aprende' or frase =='aprenda': #se o usuário digitar "aprende" o bot vai perguntar uma frase e armazenar ela associando a uma resposta
                                chave = input('Digite a frase: ')
                                chave = self.recoloca(chave)
                                resp = input('Digite a resposta: ')
                                resp = self.recoloca(resp)
                                aprendizado = ('["'+chave+','+resp+'"]')
                                self.frases[chave] = resp
                                botFrases = open('BotFrases.json','w')
                                json.dump(self.frases, botFrases)
                                botFrases.close()
                                return 'Aprendi!'
                        if self.historico[-1] == 'Olá, meu nome é '+self.nome+', qual é o seu?': #armazena na memória quem ele acabou de conhecer
                                nome = self.pegaNome(frase) #def pegaNome
                                resp = self.reconheceNome(nome) #def reconheceNome
                                return resp
                        try:
                                resp = str(eval(frase)) #"eval" permite o bot fazer qualquer operação que o Python conheça, como 1+1 = 2_
                                        #_não precisa ser programado, pois o Python já sabe
                                return resp
                        except: #caso não seja uma pergunta respondida pelo Python, como 1+1, ele pula e da o return_
                        #_nessa linha se aconteceu isso significa que é uma frase que não esta na memória dele e também não é uma operação possível para o Python
                                pass
                        return 'Não entendi'
                except:
                        return 'Não entendi'

        def pegaNome(self, nome): #pega uma frase e TENTA tirar apenas o nome da frase, TENTA
                if 'meu nome é ' in nome or 'meu nome e ' in nome:
                        nome = nome [11:]

                nome = nome.title() #como esta tudo em caixa baixa, ele vai armazenar no json nomes com a primeira letra de cada palavra em maiúsculo
                return nome

        def reconheceNome(self, nome): #se for uma pessoa dentro dos conhecidos, o bot vai agir diferente
                if nome in self.conhecidos:
                        frase = 'Oi '
                else:
                        frase = 'Muito prazer '
                        self.conhecidos.append(nome) #se for uma pessoa nova, vai adicionar aos conhecidos_
                        memoria = open(self.nome+'.json','w')
                        json.dump(self.conhecidos, memoria) #_e esse conhecido vai ser armazenado no json
                        memoria.close()
                        return frase+nome+', me pergunta alguma coisa!'
                        
                return frase+nome+', me ensina alguma coisa!'

        def fala(self, frase):
                if 'executa ' in frase: #caso tenha a palavra "executa" na frase ele vai tentar executar um programa ou site, se for Windows ou Linux
                        plataforma = sys.platform #reconhece o sistema operacional
                        comando = frase.replace('executa ','')
                        if 'win' in plataforma:
                                os.startfile(comando) #abre tanto um programa quanto um site no Windows
                        if 'linux' in plataforma:
                                try:
                                        subprocess.Popen(comando) #abre um programa no Linux_
                                except FileNotFoundError:
                                        subprocess.Popen(['xdg-open', comando]) #_se não for programa vai tentar abrir como um site
                                print(frase)
                else:
                        print(frase)
                self.historico.append(frase) #armazena na array histórico o que aconteceu
                
