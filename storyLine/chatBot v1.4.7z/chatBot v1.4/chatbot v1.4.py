print('Olá, meu nome é Lili, qual é o seu?')
nome = input('>: ')

if 'Meu nome é ' in nome:
    nome = nome [11:]

conhecidos = ['Brenda','Leonardo']

frase = 'Muito prazer '+nome+'!'
for conhecido in conhecidos:
    if nome == conhecido:
        frase = 'Oiee>< '+conhecido+' quanto tempo!'

print (frase)

while True:
    resposta = input('>: ')
    if resposta == 'Tchau':
        break
    else:
        print('Se despeça!')

print ('Tchau!')
