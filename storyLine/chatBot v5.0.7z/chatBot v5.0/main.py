from chatBot import ChatBot

bot = ChatBot("Auzio")

print ('Conectando com '+bot.nome+'...')
print ('Conectado, diga "Oi"!')
print ('Você pode digitar "Aprende", para ensinar algo ao(a) '+bot.nome+'!')
while True:
    frase = bot.escuta()
    resp = bot.pensa(frase)
    bot.fala(resp)
    if resp == 'tchau':
        break
    
