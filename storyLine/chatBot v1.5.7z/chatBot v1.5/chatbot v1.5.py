print('Olá, meu nome é Lili, qual é o seu?')
nome = input('>: ')
nome = nome.lower()
nome = nome.replace ('é','e')

if 'meu nome e ' in nome:
    nome = nome [11:]

nome = nome.title()

conhecidos = ['Brenda','Leonardo']

if nome in conhecidos:
    frase = 'Eae '+nome+'!'
else:
    frase = 'Muito prazer '+nome+'!'

print (frase)

while True:
    resposta = input('>: ')
    if resposta == 'Tchau':
        break
    else:
        print('Se despeça!')

print ('Tchau!')
