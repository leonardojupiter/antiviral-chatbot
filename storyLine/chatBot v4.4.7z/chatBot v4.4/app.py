from chatBot import ChatBot
from flask import Flask, render_template, request

bot = ChatBot("Auzio")

app = Flask(__name__)
app.static_folder = 'static'

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get")
def get_bot_response():
    frase = bot.escuta(request.args.get('msg'))
    resp = bot.pensa(frase)
    bot.fala(resp)
    return resp

if __name__ == "__main__":
    app.run()
    
#http://localhost:5000/
    
