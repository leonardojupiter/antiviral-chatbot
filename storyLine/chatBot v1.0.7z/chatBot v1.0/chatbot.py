print('Olá, qual é o seu nome?')
nome = input('>: ')
print('Muito prazer '+nome+'!')
