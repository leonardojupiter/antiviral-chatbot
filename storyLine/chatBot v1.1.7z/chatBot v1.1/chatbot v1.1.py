print('Olá, qual é o seu nome?')
nome = input('>: ')
if nome == 'Leonardo':
    print('Onii-chan!')
else:
    print('Muito prazer '+nome+'!')
    
